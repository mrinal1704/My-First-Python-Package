from setuptools import setup

setup(name='Mrinal',
      version='0.1',
      description='Basic Data Insights',
      packages=['Mrinal'],
      author = 'Mrinal Gupta',
      author_email = 'mrinalgupta1704@gmail.com',
     zip_safe=False)